﻿namespace BookShop.DataProcessor.ExportDto
{
    public class JsonBookExportModel
    {
        public string BookName { get; set; }

        public string BookPrice { get; set; }
    }
}