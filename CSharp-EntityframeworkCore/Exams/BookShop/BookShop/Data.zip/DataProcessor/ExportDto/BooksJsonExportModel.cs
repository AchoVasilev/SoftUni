﻿namespace BookShop.DataProcessor.ExportDto
{
    public class BooksJsonExportModel
    {
        public string BookName { get; set; }

        public string BookPrice { get; set; }
    }
}
