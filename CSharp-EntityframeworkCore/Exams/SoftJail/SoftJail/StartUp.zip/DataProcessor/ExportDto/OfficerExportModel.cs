﻿namespace SoftJail.DataProcessor.ExportDto
{
    public class OfficerExportModel
    {
        public string OfficerName { get; set; }

        public string Department { get; set; }
    }
}
